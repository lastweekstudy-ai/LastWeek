# AI Proxy Universal - Deployment Guide

## 🎯 Purpose

This Appwrite Function secures ALL AI API keys by moving them server-side. It supports:
- ✅ DeepSeek (chat)
- ✅ Gemini (text, vision)
- ✅ Groq (chat, vision, audio transcription)
- ✅ OpenRouter (chat, vision)

## 📦 What's Included

- `index.js` - Universal AI proxy handler
- `package.json` - Node.js dependencies (none required!)
- `aiProxyUniversal.tar.gz` - Deployment package

## 🚀 Step 1: Deploy to Appwrite

### Option A: Via Appwrite Console (Recommended)

1. Go to your Appwrite Console → Functions
2. Click "Create Function"
3. Choose "Manual deployment"
4. **Function ID:** `aiProxyUniversal`
5. **Name:** AI Proxy Universal
6. **Runtime:** Node.js 18+ (or latest)
7. **Execute Access:** Any (or restrict to authenticated users)
8. Upload `aiProxyUniversal.tar.gz`
9. Click "Deploy"

### Option B: Via Appwrite CLI

```bash
appwrite functions create \
  --functionId aiProxyUniversal \
  --name "AI Proxy Universal" \
  --runtime node-18.0

appwrite functions createDeployment \
  --functionId aiProxyUniversal \
  --activate true \
  --code aiProxyUniversal.tar.gz
```

## 🔐 Step 2: Set Environment Variables

In Appwrite Console → Functions → aiProxyUniversal → Settings → Variables:

```env
DEEPSEEK_API_KEY=sk-your-deepseek-key-here
GEMINI_API_KEY=your-gemini-key-here
GROQ_API_KEY=gsk_your-groq-key-here
OPENROUTER_API_KEY=sk-or-your-openrouter-key-here
```

**⚠️ Important:** 
- Only add keys for providers you actually use
- These are stored SECURELY in Appwrite, not exposed to clients
- You can add/update keys anytime without redeploying

## 🔧 Step 3: Update Your .env

Add this to your project's `.env` file:

```env
VITE_AI_PROXY_FUNCTION_ID=aiProxyUniversal
```

## 🧪 Step 4: Test It!

### Quick Test with Test Component

1. Add test route to your app:

```jsx
// In App.jsx or router
import SecureAITest from './components/SecureAITest';

// Add route
<Route path="/test-ai" element={<SecureAITest />} />
```

2. Navigate to `/test-ai` in your app
3. Click "Test AI Proxy"
4. Should get a response from DeepSeek!

### Manual Test with cURL

```bash
curl -X POST https://cloud.appwrite.io/v1/functions/aiProxyUniversal/executions \
  -H "Content-Type: application/json" \
  -H "X-Appwrite-Project: YOUR_PROJECT_ID" \
  -d '{
    "data": "{\"provider\":\"deepseek\",\"action\":\"chat\",\"prompt\":\"Say hello in one sentence\"}"
  }'
```

## 📋 Step 5: Migrate Existing Code

Once testing succeeds, gradually replace old AI calls:

### Before (Insecure - API key exposed):
```javascript
import { callDeepSeek } from './services/aiProvider';

const response = await callDeepSeek(systemPrompt, messages);
```

### After (Secure - via Appwrite):
```javascript
import { callDeepSeek } from './services/secureAiProvider';

const response = await callDeepSeek(systemPrompt, messages);
```

## 🔄 Migration Order (Recommended)

1. ✅ Test DeepSeek (chat sessions)
2. ✅ Migrate language learning AI calls
3. ✅ Migrate exam planner AI calls
4. ✅ Migrate PDF AI calls
5. ✅ Migrate audio lecture AI calls
6. ✅ Migrate image analysis (Gemini/Groq vision)
7. ✅ Remove old API keys from `.env`

## 📊 Monitoring

In Appwrite Console → Functions → aiProxyUniversal → Executions:
- View all AI requests
- Check response times
- Monitor errors
- Track usage per provider

## 🐛 Troubleshooting

### Error: "AI provider not configured"
- Check environment variables are set in Appwrite
- Verify key names match exactly (case-sensitive)

### Error: "Function not found"
- Check `VITE_AI_PROXY_FUNCTION_ID` in .env
- Verify function is deployed and active

### Error: "Execution failed"
- Check Appwrite function logs
- Verify payload format matches documentation

### Slow responses
- Normal for first request (cold start)
- Subsequent requests should be fast
- Consider upgrading Appwrite plan for better performance

## 🎨 Benefits

✅ **Security:** API keys never exposed to clients
✅ **Centralized:** One function for all AI providers
✅ **Monitoring:** Track all AI usage in one place
✅ **Flexibility:** Switch providers without frontend changes
✅ **Cost Control:** Easy to monitor and limit usage
✅ **Loading States:** No streaming = simpler UI

## 🔮 Next Steps

After successful deployment and testing:

1. Update all components to use `secureAiProvider.js`
2. Remove client-side API keys from `.env`
3. Update `.env.example` with new variables
4. Document the change for your team
5. Monitor usage in Appwrite console

## 📝 API Reference

See `index.js` for full API documentation. All requests follow this format:

```javascript
{
  provider: 'deepseek' | 'gemini' | 'groq' | 'openrouter',
  action: 'chat' | 'vision' | 'transcribe',
  systemPrompt?: string,
  messages?: [{role, content}],
  prompt?: string,
  model?: string,
  image?: string,  // base64
  mimeType?: string,
  audioFile?: string,  // base64
  temperature?: number,
  maxTokens?: number,
}
```

Response:
```javascript
{
  success: true,
  content: "AI response here",
  usage?: { /* token usage */ }
}
```
