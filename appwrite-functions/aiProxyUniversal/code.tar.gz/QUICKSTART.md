# ⚡ Quick Start - 5 Minute Deployment

## Step 1: Upload Function (2 min)

1. Open: https://sgp.cloud.appwrite.io/console/project-69958be2003344c314a1/functions
2. Click: **"Create Function"**
3. Fill in:
   ```
   Function ID: aiProxyUniversal
   Name: AI Proxy Universal
   Runtime: Node.js 18+
   Execute Access: Any
   ```
4. Upload: `aiProxyUniversal.tar.gz`
5. Click: **"Deploy"**
6. Wait for ✅ (deployment complete)

## Step 2: Add API Keys (2 min)

1. Click on your new function → **Settings** → **Variables**
2. Add these 3 variables:

   **Variable 1:**
   ```
   Key: DEEPSEEK_API_KEY
   Value: your_deepseek_api_key_here
   ```

   **Variable 2:**
   ```
   Key: GEMINI_API_KEY
   Value: your_gemini_api_key_here
   ```

   **Variable 3:**
   ```
   Key: GROQ_API_KEY
   Value: your_groq_api_key_here
   ```

3. Click **"Update"** after adding all

## Step 3: Test It (1 min)

1. Start your dev server: `npm run dev`
2. Go to: http://localhost:5173/test-ai
3. Click: **"Test AI Proxy"**
4. You should see: ✅ Success with AI response

## ✅ Done!

If the test works, you're ready to migrate your features!

## 🐛 If Test Fails

### Check 1: Function Status
- Go to: Functions → aiProxyUniversal
- Status should be: **Active** (green dot)

### Check 2: Variables
- Go to: Functions → aiProxyUniversal → Settings → Variables
- Should see all 3 keys listed

### Check 3: .env File
- Check: `VITE_AI_PROXY_FUNCTION_ID=aiProxyUniversal`
- If missing, add it and restart dev server

### Check 4: Function Logs
- Go to: Functions → aiProxyUniversal → Executions
- Click on latest execution
- Check logs for errors

## 📚 Next Steps

Once test succeeds:
1. See `DEPLOYMENT.md` for detailed info
2. See `../../docs/SECURE_AI_MIGRATION.md` for migration guide
3. See `../../AI_SECURITY_SUMMARY.md` for overview

## 🚨 Important Notes

- These API keys will be **hidden from browser** once you migrate
- Test page is at `/test-ai` (accessible without login)
- Function handles ALL AI providers (DeepSeek, Gemini, Groq, OpenRouter)
- First request may be slow (cold start), subsequent requests fast
- You can update API keys anytime without redeploying

## 💡 Pro Tips

- Monitor usage in: Functions → aiProxyUniversal → Executions
- Each execution shows: provider, tokens used, response time
- You can add rate limiting later if needed
- Upgrade Appwrite plan for faster cold starts

---

**Need Help?** Check the function logs first—they'll show exactly what went wrong.
