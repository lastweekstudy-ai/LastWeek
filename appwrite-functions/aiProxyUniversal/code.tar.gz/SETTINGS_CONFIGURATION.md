# ⚙️ Complete Settings & Configuration Reference

**Function:** aiProxyUniversal  
**Version:** 1.0.0  
**Last Updated:** June 2, 2026

---

## 📋 Table of Contents

1. [Appwrite Function Settings](#appwrite-function-settings)
2. [Environment Variables](#environment-variables)
3. [Execution Settings](#execution-settings)
4. [Network & Security](#network--security)
5. [Monitoring Configuration](#monitoring-configuration)
6. [Frontend Configuration](#frontend-configuration)

---

## Appwrite Function Settings

### Basic Information

```yaml
Function ID: aiProxyUniversal
Name: AI Proxy Universal
Description: Secure AI proxy for DeepSeek, Gemini, and Groq
Status: Active
```

### Runtime Configuration

```yaml
Runtime: Node.js 18+ (or latest available)
Entry Point: index.js
Build Command: (none - pre-built)
Install Command: (none - no dependencies)
```

### File Structure

```
aiProxyUniversal/
├── index.js          # Main handler (330+ lines)
├── package.json      # Metadata, no dependencies
└── README.md         # Optional documentation
```

---

## Environment Variables

### Required Variables (3 total)

All must be set in: **Appwrite Console → Functions → aiProxyUniversal → Settings → Variables**

#### 1. DeepSeek API Key

```yaml
Key:         DEEPSEEK_API_KEY
Value:       your_deepseek_api_key_here
Type:        Secret
Required:    Yes
Description: Access to DeepSeek AI for chat and reasoning
Provider:    DeepSeek (https://platform.deepseek.com)
```

**Usage in function:**
```javascript
const DEEPSEEK_API_KEY = process.env.DEEPSEEK_API_KEY;
```

**Features enabled:**
- Chat completions
- Deep reasoning
- Long context handling
- Failover for Groq rate limits

---

#### 2. Gemini API Key

```yaml
Key:         GEMINI_API_KEY  
Value:       your_gemini_api_key_here
Type:        Secret
Required:    Yes
Description: Access to Google Gemini AI for vision and documents
Provider:    Google AI Studio (https://makersuite.google.com/app/apikey)
```

**Usage in function:**
```javascript
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
```

**Features enabled:**
- Image analysis (vision)
- Document understanding (2M context)
- PDF processing
- Multilingual support
- Structured JSON output

---

#### 3. Groq API Key

```yaml
Key:         GROQ_API_KEY
Value:       your_groq_api_key_here
Type:        Secret
Required:    Yes
Description: Access to Groq for fast inference and audio transcription
Provider:    Groq (https://console.groq.com)
```

**Usage in function:**
```javascript
const GROQ_API_KEY = process.env.GROQ_API_KEY;
```

**Features enabled:**
- Fast LLM inference (Llama models)
- Audio transcription (Whisper)
- Vision analysis (Llama Vision)
- Primary provider for quick responses

---

### Variable Configuration Best Practices

#### How to Add Variables

**Step-by-step:**

1. Go to Appwrite Console
2. Navigate to: **Functions → aiProxyUniversal**
3. Click: **Settings** tab
4. Find: **Environment Variables** section
5. Click: **"Add Variable"** button
6. Enter:
   - **Key:** Exact name (case-sensitive)
   - **Value:** API key (paste directly, no quotes)
7. Click: **"Create"** or **"Save"**
8. Repeat for all 3 keys

#### Verification Checklist

- [ ] All 3 variables show in list
- [ ] Keys show as `••••••` (hidden for security)
- [ ] No typos in key names (case-sensitive!)
- [ ] Values have no extra spaces or quotes
- [ ] Click "Update" button if needed

#### Common Mistakes to Avoid

❌ **Wrong key name:**
```
DEEPSEEK_KEY        # ❌ Missing _API
deepseek_api_key    # ❌ Wrong case
DeepSeek_API_Key    # ❌ Wrong case
```

✅ **Correct key name:**
```
DEEPSEEK_API_KEY    # ✅ Exact match
```

❌ **Wrong value format:**
```
"sk-abc123"         # ❌ Has quotes
 sk-abc123          # ❌ Leading space
sk-abc123           # ❌ Trailing space
Bearer sk-abc123    # ❌ Has prefix
```

✅ **Correct value format:**
```
sk-abc123           # ✅ Just the key
```

---

## Execution Settings

### Timeout Configuration

```yaml
Timeout: 60 seconds
Recommended: 60-90 seconds
Minimum: 30 seconds
Maximum: 900 seconds (15 minutes)
```

**Why 60 seconds:**
- AI requests typically take 2-10 seconds
- Allows for network latency
- Handles slow AI provider responses
- Prevents stuck executions

**When to increase:**
- If you see frequent timeout errors
- For very large document processing
- For complex vision analysis
- For long audio transcription

**How to change:**
```
Appwrite Console → Functions → aiProxyUniversal → Settings
Look for: "Timeout" field
Change value: 90 (for 90 seconds)
Click: "Update"
```

### Execution Limits

```yaml
Max Concurrent Executions: 10 (default)
Can be increased: Yes (upgrade plan)
Rate Limiting: None (handled by AI providers)
```

**Understanding limits:**
- **Free tier:** 10 concurrent executions
- **Pro tier:** 100 concurrent executions
- **Enterprise:** Custom limits

---

## Network & Security

### Execute Access Control

```yaml
Current Setting: Any
Options:
  - Any: Anyone can execute (including unauthenticated)
  - Authenticated: Only logged-in users
  - Teams: Specific team members only
  - Users: Specific users only
```

**Recommended settings:**

| Environment | Setting | Reason |
|-------------|---------|--------|
| **Development** | Any | Easy testing |
| **Staging** | Authenticated | Controlled access |
| **Production** | Authenticated | Security best practice |

**How to change:**
```
Settings → Execute Access
Select: "Authenticated"
Click: "Update"
```

### CORS Configuration

**Current headers (in code):**
```javascript
{
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, x-appwrite-key',
  'Content-Type': 'application/json',
}
```

**For production (more secure):**

1. Open `index.js`
2. Change line 45:
```javascript
// Before
'Access-Control-Allow-Origin': '*',

// After (your domain only)
'Access-Control-Allow-Origin': 'https://lastweek.app',
```

3. Rebuild and redeploy

### API Endpoints

**Function URL:**
```
https://sgp.cloud.appwrite.io/v1/functions/aiProxyUniversal/executions
```

**Request format:**
```javascript
{
  "data": JSON.stringify({
    provider: "deepseek",
    action: "chat",
    systemPrompt: "You are a helpful assistant",
    messages: [{role: "user", content: "Hello"}]
  })
}
```

---

## Monitoring Configuration

### Logging Level

```yaml
Current: INFO
Available: DEBUG, INFO, WARN, ERROR
Recommendation: INFO (default)
```

**Log output locations:**
- Appwrite Console → Executions tab
- Function standard output (stdout)
- Function error output (stderr)

### What Gets Logged

**Success logs:**
```
[aiProxy] deepseek chat request
[DeepSeek] Calling with 2 messages
[DeepSeek] Success, 150 chars
```

**Error logs:**
```
[aiProxy] Error: DEEPSEEK_API_KEY not configured
[DeepSeek] DeepSeek failed: Rate limit exceeded
```

**Request logs (debug):**
```javascript
log(`[aiProxy] ${provider} ${action} request`);
```

### Metrics to Monitor

| Metric | Where to Find | Good Value |
|--------|---------------|------------|
| **Success Rate** | Executions tab | >99% |
| **Avg Duration** | Execution details | 2-5 seconds |
| **Error Rate** | Failed executions | <1% |
| **Cold Start** | First execution | 5-10 seconds |
| **Warm Start** | Subsequent | 2-3 seconds |

### Setting Up Monitoring (Pro Feature)

**If you have Appwrite Pro:**

1. **Go to:** Functions → aiProxyUniversal → Monitoring
2. **Enable alerts for:**
   - Execution failures (>5%)
   - Slow responses (>10s)
   - High error rate (>1%)
3. **Set notification channels:**
   - Email
   - Webhook
   - Slack integration

---

## Frontend Configuration

### Required Environment Variables

**File:** `d:\LastWeek\LastWeek\.env`

```env
# AI Proxy Function ID
VITE_AI_PROXY_FUNCTION_ID=aiProxyUniversal
```

**Verification:**

1. Open `.env` file
2. Search for `VITE_AI_PROXY_FUNCTION_ID`
3. Value should be: `aiProxyUniversal`
4. If missing, add it
5. Restart dev server

### How Frontend Uses It

**In `secureAiProvider.js`:**
```javascript
const AI_PROXY_FUNCTION_ID = import.meta.env.VITE_AI_PROXY_FUNCTION_ID || 'aiProxyUniversal';

async function callAiProxy(payload) {
  const execution = await functions.createExecution(
    AI_PROXY_FUNCTION_ID,  // Uses this value
    JSON.stringify(payload),
    false
  );
  // ...
}
```

### Build-Time Configuration

**For production build:**

1. **Update `.env.production`:**
   ```env
   VITE_AI_PROXY_FUNCTION_ID=aiProxyUniversal
   VITE_APPWRITE_PROJECT_ID=69958be2003344c314a1
   VITE_APPWRITE_ENDPOINT=https://sgp.cloud.appwrite.io/v1
   ```

2. **Build:**
   ```bash
   npm run build
   ```

3. **Verify in `dist/` folder:**
   - Function ID is hardcoded in compiled JS
   - No secrets included (all server-side)

---

## Complete Configuration Checklist

### Appwrite Console Configuration

- [ ] **Function Created**
  - [ ] ID: `aiProxyUniversal`
  - [ ] Name: AI Proxy Universal
  - [ ] Runtime: Node.js 18+
  - [ ] Status: Active ✅

- [ ] **Code Deployed**
  - [ ] File: `aiProxyUniversal.tar.gz` uploaded
  - [ ] Deployment: Active
  - [ ] Build: Successful

- [ ] **Environment Variables**
  - [ ] `DEEPSEEK_API_KEY` = `your_deepseek_api_key_here`
  - [ ] `GEMINI_API_KEY` = `your_gemini_api_key_here`
  - [ ] `GROQ_API_KEY` = `your_groq_api_key_here`

- [ ] **Execution Settings**
  - [ ] Timeout: 60 seconds
  - [ ] Execute Access: Any (or Authenticated)
  - [ ] Region: Singapore (sgp)

### Frontend Configuration

- [ ] **Environment File (.env)**
  - [ ] `VITE_AI_PROXY_FUNCTION_ID=aiProxyUniversal`
  - [ ] No old API keys (commented out)

- [ ] **Code Updates**
  - [ ] `aiProvider.js` uses secure proxy
  - [ ] Test component added at `/test-ai`
  - [ ] Dev server restarted

- [ ] **Build Configuration**
  - [ ] `.env.production` updated
  - [ ] Build succeeds with no errors
  - [ ] Function ID included in bundle

### Testing Configuration

- [ ] **Test Page Works**
  - [ ] `/test-ai` loads
  - [ ] Button click sends request
  - [ ] Response received successfully

- [ ] **All Features Work**
  - [ ] Chat sessions
  - [ ] Language learning
  - [ ] Exam planner
  - [ ] PDF analysis
  - [ ] Image analysis
  - [ ] Audio transcription

---

## Configuration Files Reference

### 1. Appwrite Function Files

**Location:** `d:\LastWeek\LastWeek\appwrite-functions\aiProxyUniversal\`

```
aiProxyUniversal/
├── index.js                          # Main function code
├── package.json                      # Metadata
├── aiProxyUniversal.tar.gz          # Deployment package
├── DEPLOYMENT.md                     # Deployment guide
├── QUICKSTART.md                     # Quick start guide
├── COMPLETE_DEPLOYMENT_GUIDE.md     # This guide
└── SETTINGS_CONFIGURATION.md        # You are here
```

### 2. Frontend Configuration Files

**Location:** `d:\LastWeek\LastWeek\`

```
.env                    # Development environment variables
.env.example            # Template for new developers
.env.production         # Production environment variables (optional)
```

### 3. Source Code Files

**Location:** `d:\LastWeek\LastWeek\src\`

```
services/
├── aiProvider.js          # Uses secure proxy (updated)
└── secureAiProvider.js    # Secure SDK (new)

components/
└── SecureAITest.jsx       # Test component (new)
```

---

## Quick Reference: All Settings

### Appwrite Console Settings

```yaml
Function Settings:
  ID: aiProxyUniversal
  Name: AI Proxy Universal
  Runtime: Node.js 18+
  Timeout: 60 seconds
  Execute Access: Any
  Status: Active

Environment Variables:
  DEEPSEEK_API_KEY: your_deepseek_api_key_here
  GEMINI_API_KEY: your_gemini_api_key_here
  GROQ_API_KEY: your_groq_api_key_here

Deployment:
  Package: aiProxyUniversal.tar.gz
  Size: ~3 KB
  Files: index.js, package.json
  Build Status: Success
```

### Frontend Settings (.env)

```env
# Appwrite Configuration
VITE_APPWRITE_PROJECT_ID=69958be2003344c314a1
VITE_APPWRITE_ENDPOINT=https://sgp.cloud.appwrite.io/v1
VITE_APPWRITE_DATABASE_ID=69f742a2001f393e4b85

# AI Proxy Function
VITE_AI_PROXY_FUNCTION_ID=aiProxyUniversal

# Old API Keys (DEPRECATED - no longer used)
# VITE_DEEPSEEK_API_KEY=...
# VITE_GEMINI_API_KEY=...
# VITE_GROQ_API_KEY=...
```

---

## Troubleshooting Settings

### "Function not found"

**Check:**
1. Function ID in Appwrite: `aiProxyUniversal`
2. `.env` file: `VITE_AI_PROXY_FUNCTION_ID=aiProxyUniversal`
3. Dev server restarted

### "Provider not configured"

**Check:**
1. Environment variables are set in Appwrite
2. Variable names match exactly (case-sensitive)
3. Values have no extra spaces or quotes

### "Timeout"

**Check:**
1. Timeout setting: Should be ≥60 seconds
2. AI provider status: Check if slow/down
3. Consider increasing timeout to 90 seconds

### "CORS error"

**Check:**
1. CORS headers in `index.js`
2. If locked down, add your domain
3. Clear browser cache

---

## Next Steps

After configuration:

1. ✅ **Test:** Visit `/test-ai` and verify
2. ✅ **Monitor:** Check Executions tab in Appwrite
3. ✅ **Use:** All features now secure
4. ✅ **Remove:** Old API keys from `.env` (optional)
5. ✅ **Deploy:** Push to production when ready

---

**✨ Configuration Complete!**

All settings are now properly configured. Your AI proxy is secure, monitored, and ready for production use.
