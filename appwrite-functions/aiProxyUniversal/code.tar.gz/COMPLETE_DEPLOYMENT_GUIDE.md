# 🚀 Complete Deployment Guide - AI Proxy Universal

**Last Updated:** June 2, 2026  
**Status:** Production Ready  
**Providers:** DeepSeek, Gemini, Groq

---

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Step-by-Step Deployment](#step-by-step-deployment)
3. [Environment Variables Configuration](#environment-variables-configuration)
4. [Testing & Verification](#testing--verification)
5. [Troubleshooting](#troubleshooting)
6. [Monitoring & Logs](#monitoring--logs)
7. [Updating the Function](#updating-the-function)

---

## Prerequisites

### Required Accounts & Keys

- ✅ **Appwrite Account** (Free tier works)
  - Project ID: `69958be2003344c314a1`
  - Endpoint: `https://sgp.cloud.appwrite.io/v1`

- ✅ **API Keys** (You already have these):
  ```
  DeepSeek: your_deepseek_api_key_here
  Gemini: your_gemini_api_key_here
  Groq: your_groq_api_key_here
  ```

### Files You Need

- ✅ `aiProxyUniversal.tar.gz` (located in `appwrite-functions/` folder)
- ✅ Size: ~3 KB
- ✅ Contents: `index.js` + `package.json`

---

## Step-by-Step Deployment

### Step 1: Access Appwrite Console

1. **Open your browser** and navigate to:
   ```
   https://sgp.cloud.appwrite.io/console/project-69958be2003344c314a1/functions
   ```

2. **Login** if not already logged in

3. You should see your **Functions** dashboard

---

### Step 2: Create New Function

1. **Click** the **"Create Function"** button (usually top-right)

2. **Fill in the form:**

   | Field | Value |
   |-------|-------|
   | **Function ID** | `aiProxyUniversal` |
   | **Name** | AI Proxy Universal |
   | **Runtime** | Node.js 18+ (or latest available) |
   | **Execute Access** | `Any` (or `Authenticated` for extra security) |
   | **Events** | Leave empty |
   | **Timeout** | 60 seconds |
   | **Region** | Same as your project (Singapore) |

3. **Click "Create"** or "Next"

---

### Step 3: Deploy Function Code

1. **Upload the tarball:**
   - Look for "**Upload Code**" or "**Deployment**" section
   - Click "**Choose File**" or drag-and-drop
   - Select: `appwrite-functions/aiProxyUniversal.tar.gz`

2. **Wait for upload:**
   - File uploads (3KB, should be instant)
   - Appwrite will extract and validate the code

3. **Activate deployment:**
   - Click "**Deploy**" or "**Activate**" button
   - Wait for build to complete (1-2 minutes)
   - Status should change to **"Active"** with green checkmark ✅

---

### Step 4: Configure Environment Variables

This is **crucial** - the function needs your API keys!

1. **Navigate to Settings:**
   - In your function page, click **"Settings"** tab
   - Look for **"Environment Variables"** or **"Variables"** section

2. **Add Variable 1 - DeepSeek:**
   ```
   Key:   DEEPSEEK_API_KEY
   Value: your_deepseek_api_key_here
   ```
   - Click **"Add"** or **"+"**
   - Enter key and value exactly as shown
   - Click **"Save"** or **"Create"**

3. **Add Variable 2 - Gemini:**
   ```
   Key:   GEMINI_API_KEY
   Value: your_gemini_api_key_here
   ```
   - Repeat the same process

4. **Add Variable 3 - Groq:**
   ```
   Key:   GROQ_API_KEY
   Value: your_groq_api_key_here
   ```
   - Repeat the same process

5. **Verify all 3 variables are saved:**
   - You should see all three listed
   - Values should show as `••••••` (hidden for security)

6. **Click "Update" if needed** to apply changes

---

### Step 5: Update Your Project .env

Your frontend needs to know the function ID:

1. **Open:** `d:\LastWeek\LastWeek\.env`

2. **Verify this line exists:**
   ```env
   VITE_AI_PROXY_FUNCTION_ID=aiProxyUniversal
   ```

3. **If not, add it** under the Functions section

4. **Save the file**

5. **Restart your dev server:**
   ```bash
   npm run dev
   ```

---

## Environment Variables Configuration

### Complete Reference

Here's what each variable does:

| Variable | Purpose | Required | Default |
|----------|---------|----------|---------|
| `DEEPSEEK_API_KEY` | Access to DeepSeek AI (chat, reasoning) | ✅ Yes | None |
| `GEMINI_API_KEY` | Access to Gemini AI (vision, documents, chat) | ✅ Yes | None |
| `GROQ_API_KEY` | Access to Groq AI (Llama models, Whisper transcription) | ✅ Yes | None |

### Security Notes

- ✅ **Stored securely** in Appwrite (encrypted at rest)
- ✅ **Never exposed** to client code
- ✅ **Only accessible** by the function at runtime
- ✅ **Hidden in UI** (shows as `••••••`)
- ✅ **Can be updated** anytime without redeploying

### Variable Format Rules

- **Keys are case-sensitive:** `DEEPSEEK_API_KEY` ≠ `deepseek_api_key`
- **No spaces:** `GROQ_API_KEY` not `GROQ API KEY`
- **No quotes:** Just paste the key value directly
- **No prefixes:** Don't add `Bearer` or anything else

---

## Testing & Verification

### Quick Test (2 minutes)

1. **Navigate to test page:**
   ```
   http://localhost:5173/test-ai
   ```

2. **You should see:**
   - Title: "🔐 Secure AI Proxy Test"
   - A text area with a sample prompt
   - A button: "🚀 Test AI Proxy"

3. **Click the button**

4. **Expected result:**
   - Loading indicator appears
   - After 2-5 seconds, you see:
   - ✅ **"Success! AI Response:"**
   - A fun fact about space (or similar)

5. **If successful:**
   - ✅ Function deployed correctly
   - ✅ API keys configured correctly
   - ✅ Network connection working
   - ✅ Ready to use!

### Verify in Appwrite Console

1. **Go to:** Functions → aiProxyUniversal → **Executions**

2. **You should see:**
   - A new execution entry
   - Status: **Completed** (green)
   - Duration: 2-5 seconds
   - Logs showing: `[aiProxy] deepseek chat request`

3. **Click on the execution** to see:
   - Full logs
   - Request/response data
   - Any errors (if occurred)

---

## Troubleshooting

### Issue 1: "Function not found"

**Symptom:** Test page shows error "Function not found"

**Causes & Solutions:**

1. **Check .env file:**
   ```env
   VITE_AI_PROXY_FUNCTION_ID=aiProxyUniversal
   ```
   - Make sure this line exists
   - Check spelling is exact (case-sensitive)

2. **Restart dev server:**
   ```bash
   # Stop current server (Ctrl+C)
   npm run dev
   ```

3. **Verify function ID in Appwrite:**
   - Go to Functions list
   - Check the ID column
   - Should match: `aiProxyUniversal`

---

### Issue 2: "AI provider not configured"

**Symptom:** Test shows error about provider not configured

**Causes & Solutions:**

1. **Check environment variables:**
   - Go to: Functions → aiProxyUniversal → Settings → Variables
   - Verify all 3 keys are listed
   - Names must be **exact** (case-sensitive)

2. **Verify key values:**
   - Keys should **not** be empty
   - Should show as `••••••` (hidden)
   - Click "Edit" to verify actual values

3. **Re-enter a key if needed:**
   - Delete the variable
   - Add it again with correct key/value
   - Click "Update" to save

---

### Issue 3: "Execution failed"

**Symptom:** Function execution shows "Failed" status

**How to diagnose:**

1. **Check function logs:**
   - Functions → aiProxyUniversal → Executions
   - Click on the failed execution
   - Read the error logs

2. **Common errors:**

   **"DEEPSEEK_API_KEY not set"**
   - Solution: Add environment variable

   **"Invalid API key"**
   - Solution: Double-check key value (no extra spaces)

   **"Network error"**
   - Solution: Check Appwrite network connectivity
   - Try again (might be temporary)

   **"Timeout"**
   - Solution: Increase timeout in function settings
   - Or try again (AI provider might be slow)

---

### Issue 4: Slow Response

**Symptom:** Takes >10 seconds to respond

**Causes & Solutions:**

1. **First request (cold start):**
   - Normal: 5-10 seconds for first call
   - Appwrite needs to wake up the function
   - Subsequent calls should be 2-5 seconds

2. **AI provider slowness:**
   - DeepSeek might be busy
   - Try again
   - Check AI provider status pages

3. **Network latency:**
   - Your Appwrite region: Singapore
   - Check your internet connection
   - Consider upgrading Appwrite plan for faster cold starts

---

### Issue 5: Test Page Blank

**Symptom:** `/test-ai` shows blank page

**Causes & Solutions:**

1. **Check route is added:**
   - Open: `src/App.jsx`
   - Search for: `/test-ai`
   - Should see: `<Route path="/test-ai" element={<SecureAITest />} />`

2. **Check import:**
   - Top of `App.jsx` should have:
   ```javascript
   import SecureAITest from './components/SecureAITest';
   ```

3. **Restart dev server:**
   ```bash
   npm run dev
   ```

4. **Check browser console:**
   - Press F12
   - Look for error messages
   - Fix any import errors

---

## Monitoring & Logs

### Accessing Logs

1. **Real-time monitoring:**
   ```
   Appwrite Console → Functions → aiProxyUniversal → Executions
   ```

2. **What you'll see:**
   - **List of all executions** (newest first)
   - **Status:** Completed, Failed, Running
   - **Duration:** How long it took
   - **Timestamp:** When it ran

3. **Click any execution** to see:
   - Full request payload
   - Full response
   - Console logs
   - Errors (if any)

### Understanding Logs

**Successful execution logs:**
```
[aiProxy] deepseek chat request
[DeepSeek] Calling with 2 messages
[DeepSeek] Success, 150 chars
```

**Failed execution logs:**
```
[aiProxy] Error: DEEPSEEK_API_KEY not set
```

### Performance Metrics

**Expected values:**

| Metric | Good | Acceptable | Poor |
|--------|------|------------|------|
| **Cold start** | 3-5s | 5-10s | >10s |
| **Warm request** | 1-3s | 3-5s | >5s |
| **Success rate** | >99% | >95% | <95% |
| **Error rate** | <1% | <5% | >5% |

### Setting Up Alerts (Optional)

If you upgrade to Appwrite Pro:

1. **Go to:** Functions → aiProxyUniversal → Alerts
2. **Create alert for:**
   - Error rate >5%
   - Response time >10s
   - Function failures
3. **Set notification method** (email, webhook, etc.)

---

## Updating the Function

### When to Update

- When you need to add a new AI provider
- When you need to change request/response format
- When you need to add new features
- When fixing bugs

### How to Update

1. **Edit the code:**
   - Modify: `appwrite-functions/aiProxyUniversal/index.js`
   - Make your changes
   - Save the file

2. **Rebuild tarball:**
   ```bash
   cd appwrite-functions/aiProxyUniversal
   tar -czf ../aiProxyUniversal.tar.gz index.js package.json
   ```

3. **Upload to Appwrite:**
   - Functions → aiProxyUniversal → Deployments
   - Click "Create Deployment"
   - Upload new tarball
   - Click "Activate" after build completes

4. **Test the update:**
   - Visit `/test-ai`
   - Verify functionality works
   - Check logs for errors

### Version Control

**Good practice:**

1. **Tag your deployments:**
   ```bash
   git tag -a v1.0.1 -m "Fixed Groq vision timeout"
   git push --tags
   ```

2. **Keep old tarballs:**
   ```bash
   cp aiProxyUniversal.tar.gz aiProxyUniversal-v1.0.1.tar.gz
   ```

3. **Document changes:**
   - Update DEPLOYMENT.md
   - Note what changed
   - Note deployment date

---

## Environment Variables - Complete List

### Production Settings

Copy this exactly into Appwrite Console → Functions → aiProxyUniversal → Settings → Variables:

```
# Variable 1
Key:   DEEPSEEK_API_KEY
Value: your_deepseek_api_key_here

# Variable 2
Key:   GEMINI_API_KEY
Value: your_gemini_api_key_here

# Variable 3
Key:   GROQ_API_KEY
Value: your_groq_api_key_here
```

### How to Add Variables (Detailed)

**Method 1: Appwrite Console UI**

1. Click "**Add Variable**" button
2. Enter **Key** (exact case-sensitive name)
3. Enter **Value** (paste API key)
4. Click "**Create**" or "**Save**"
5. Repeat for all 3 keys

**Method 2: Appwrite CLI (Advanced)**

```bash
appwrite functions updateVariables \
  --functionId aiProxyUniversal \
  --key DEEPSEEK_API_KEY \
  --value "your_deepseek_api_key_here"

appwrite functions updateVariables \
  --functionId aiProxyUniversal \
  --key GEMINI_API_KEY \
  --value "your_gemini_api_key_here"

appwrite functions updateVariables \
  --functionId aiProxyUniversal \
  --key GROQ_API_KEY \
  --value "your_groq_api_key_here"
```

### Variable Security Best Practices

✅ **DO:**
- Store keys in Appwrite environment variables
- Use different keys for dev/staging/production
- Rotate keys periodically (every 3-6 months)
- Monitor usage for anomalies
- Set up billing alerts with AI providers

❌ **DON'T:**
- Store keys in code
- Commit keys to git
- Share keys in Slack/email
- Use same keys across multiple projects
- Expose keys in logs or error messages

---

## Success Checklist

Use this to verify deployment:

- [ ] **Function Created**
  - [ ] ID is `aiProxyUniversal`
  - [ ] Runtime is Node.js 18+
  - [ ] Status shows "Active" ✅

- [ ] **Code Deployed**
  - [ ] Uploaded `aiProxyUniversal.tar.gz`
  - [ ] Deployment status: Completed
  - [ ] No build errors

- [ ] **Environment Variables Set**
  - [ ] `DEEPSEEK_API_KEY` added
  - [ ] `GEMINI_API_KEY` added
  - [ ] `GROQ_API_KEY` added
  - [ ] All show as `••••••` (hidden)

- [ ] **Frontend Configured**
  - [ ] `.env` has `VITE_AI_PROXY_FUNCTION_ID=aiProxyUniversal`
  - [ ] Dev server restarted

- [ ] **Tested**
  - [ ] Visited `/test-ai`
  - [ ] Clicked "Test AI Proxy"
  - [ ] Got successful response ✅
  - [ ] Checked Appwrite logs

- [ ] **Monitored**
  - [ ] Execution appears in Appwrite
  - [ ] Status is "Completed"
  - [ ] Logs show success messages

---

## Quick Reference Commands

### Check Function Status
```bash
# In Appwrite Console
Functions → aiProxyUniversal → Overview
Look for: "Active" badge (green)
```

### View Latest Logs
```bash
# In Appwrite Console
Functions → aiProxyUniversal → Executions
Click: Most recent execution
Read: Console logs
```

### Test Function
```bash
# In browser
http://localhost:5173/test-ai
Click: "Test AI Proxy" button
Expect: Success message
```

### Rebuild Tarball
```bash
cd d:\LastWeek\LastWeek\appwrite-functions\aiProxyUniversal
tar -czf ../aiProxyUniversal.tar.gz index.js package.json
```

---

## Support & Resources

### Official Documentation

- **Appwrite Functions:** https://appwrite.io/docs/functions
- **Environment Variables:** https://appwrite.io/docs/functions#environment-variables
- **Deployments:** https://appwrite.io/docs/functions#deployments

### Your Project Resources

- **Test Page:** `http://localhost:5173/test-ai`
- **Appwrite Console:** `https://sgp.cloud.appwrite.io/console`
- **Function Logs:** `Functions → aiProxyUniversal → Executions`

### Troubleshooting Resources

1. **Check function logs** (first)
2. **Read this guide** (troubleshooting section)
3. **Check browser console** (F12)
4. **Verify environment variables** (Settings → Variables)

---

## Appendix: AI Provider Details

### DeepSeek
- **Purpose:** Primary chat, reasoning tasks
- **Cost:** $0.14-$0.28 per 1M tokens (paid)
- **Limits:** No strict TPM limits
- **Best for:** Long conversations, complex reasoning

### Gemini
- **Purpose:** Vision, documents, multilingual
- **Cost:** Free tier (1500 RPD, 15 RPM)
- **Limits:** 2M context window
- **Best for:** PDF analysis, image understanding

### Groq
- **Purpose:** Fast inference, audio transcription
- **Cost:** Free tier (various models)
- **Limits:** Model-specific TPM limits
- **Best for:** Real-time responses, Whisper transcription

---

**🎉 Deployment Complete!**

If you followed all steps, your AI proxy is now:
- ✅ Deployed and active
- ✅ Fully configured
- ✅ Tested and working
- ✅ Ready for production use

**Next:** Test all your features (chat, language learning, exam planner, etc.) to ensure they work with the secure proxy!
